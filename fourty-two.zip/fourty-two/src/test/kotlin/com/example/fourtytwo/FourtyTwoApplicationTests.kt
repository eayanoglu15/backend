package com.example.fourtytwo

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class FourtyTwoApplicationTests {

    @Test
    fun contextLoads() {
    }

}

alter table public.trip
add column distance double precision default 0.0;

package com.example.fourtytwo.modules.users.request

data class LoginRequest (
        var username: String,
        var password: String
)
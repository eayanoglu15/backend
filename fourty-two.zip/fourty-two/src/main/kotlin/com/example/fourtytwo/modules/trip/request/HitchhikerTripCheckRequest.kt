package com.example.fourtytwo.modules.trip.request


data class HitchhikerTripCheckRequest(
        var hitchhikerUserName: String
)
package com.example.fourtytwo.modules.users.request

data class ReviewUser (
        var review:Int,
        var receiverUsername: String,
        var giverUsername: String

)
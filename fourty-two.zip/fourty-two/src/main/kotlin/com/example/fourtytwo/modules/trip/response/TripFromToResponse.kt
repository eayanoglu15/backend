package com.example.fourtytwo.modules.trip.response


data class TripFromToResponse(
        val fromToLocationList: List<String> = listOf("Hacıosman","Levent","Koç Batı","Beşiktaş","Kadıköy")
)
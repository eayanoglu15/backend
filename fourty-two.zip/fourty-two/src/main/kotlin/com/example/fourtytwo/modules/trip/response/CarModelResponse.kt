package com.example.fourtytwo.modules.trip.response


data class CarModelResponse(
        val audiA6: String? = "Audi A6",
        val mercedesC180: String? = "Mercedes C180",
        val ferrariF50: String? = "Ferrari F50",
        val bugattiVeyron: String? = "Bugatti Veyron",
        val bmw520: String? = "BMW 520"

)
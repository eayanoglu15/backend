package com.example.fourtytwo.modules.trip.request


data class DriverTripCheckRequest(
        var driverUserName: String
)
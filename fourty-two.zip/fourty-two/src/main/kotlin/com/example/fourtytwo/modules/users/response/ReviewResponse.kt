package com.example.fourtytwo.modules.users.response

data class ReviewResponse (
        var updatedReviewPoint:Double
)
package com.example.fourtytwo.modules.trip.request

data class AcceptTripRequest(
        var tripRequestId: Long? = null
)